
from .base import ABERTURA, NAMESPACE_NFE, NAMESPACE_SIG, NAMESPACE_NFSE, NAMESPACE_CTE,\
    TagCaracter, TagData, TagDataHora, TagDataHoraUTC,TagDecimal, TagHora, TagInteiro, \
    XMLNFe, tira_abertura, tirar_acentos, por_acentos


from .assinatura import Signature