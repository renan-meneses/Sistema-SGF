# -*- coding: utf-8 -*-

from .processador_cte import *